# materialsML

A Machine Learning package for materials informatics.

### notes 
run tests with `poetry run pytest -v -s`