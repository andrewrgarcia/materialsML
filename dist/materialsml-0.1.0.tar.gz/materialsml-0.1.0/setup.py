# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['materialsml']

package_data = \
{'': ['*']}

install_requires = \
['mp-api>=0.30.5,<0.31.0',
 'mpcontribs-client>=5.0.7,<6.0.0',
 'pytest>=7.2.0,<8.0.0',
 'stellargraph>=1.2.1,<2.0.0']

setup_kwargs = {
    'name': 'materialsml',
    'version': '0.1.0',
    'description': 'A Machine Learning package for materials informatics',
    'long_description': '# materialsML\n\nA Machine Learning package for materials informatics.\n\n### notes \nrun tests with `poetry run pytest -v -s`',
    'author': 'andrewrgarcia',
    'author_email': 'garcia.gtr@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.8.3',
}


setup(**setup_kwargs)
